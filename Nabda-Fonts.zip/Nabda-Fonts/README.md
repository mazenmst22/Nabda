# Nabda — Brand Fonts

Three families, all under the **SIL Open Font License 1.1**. Free for commercial use,
app embedding, web serving and client work. No subscription, no seat count, no per-view
fee. The only real obligations: keep the licence files with the fonts, and don't sell
the fonts on their own.

| Role | Family | Weights you use | Never |
|---|---|---|---|
| Display & wordmark | **Readex Pro** | 200 · 300 · 400 · 500 · 600 | 700 — it closes up the counters |
| Interface & body | **IBM Plex Sans Arabic** | 300 · 400 · 500 · 600 | — |
| Data & labels | **IBM Plex Mono** | 400 · 500 | Arabic — it has none |

Both text families ship Arabic and Latin from the same drawing office. That is the whole
reason they were chosen: a headline in عربي and a headline in English are siblings, not
translations, and bilingual lockups need no optical fudging.

---

## What's in the box

```
desktop/     19 .ttf files — install these on your machine
web/         .woff2 + ready-to-paste CSS for the site and app
licenses/    the OFL for each family — ship these with the fonts
specimen.html  open in a browser to check everything loaded
```

### desktop/
Install these into Windows, and they appear in Figma (desktop app), Illustrator,
InDesign, Word, PowerPoint and Canva (via brand upload).

- `ReadexPro-VariableFont.ttf` — one file, every weight 200–700 on a slider.
  Figma, Illustrator and InDesign handle it. **Word and PowerPoint do not.**
- `ReadexPro-ExtraLight/Light/Regular/Medium/SemiBold/Bold.ttf` — six fixed weights,
  cut from the variable font and renamed so Windows groups them under one
  "Readex Pro" family instead of six. Install **these** for Office.
- `IBMPlexSansArabic-*.ttf` — seven weights, Thin through Bold.
- `IBMPlexMono-*.ttf` — Regular, Medium, SemiBold, Bold, Italic.

**Install on Windows:** select all the .ttf files in `desktop/`, right-click →
**Install for all users**. (Plain "Install" works too but only for your account, and
some apps won't see them.) Restart any app that was already open — Figma and Office
only scan fonts at launch.

Don't install both the variable file and the six statics if you can avoid it — some
apps list both and you end up picking the wrong one. Pick the route that matches
your tools: variable for design apps, statics for Office.

### web/
- `nabda-fonts.css` — @font-face rules plus the Nabda type tokens and scale,
  including the Arabic overrides (+8% size, +0.15 line-height, no tracking,
  no uppercase). Drop it in and reference `var(--f-display)` / `var(--f-body)` / `var(--f-mono)`.
- `preload-snippet.html` — the `<head>` tags, with the Google Fonts CDN
  equivalent commented underneath if you'd rather not self-host.
- `subset/` — **ship these.** Latin + Arabic only. The whole set is ~250 KB;
  the two faces above the fold are ~91 KB.
- `full/` — every glyph the families contain (Cyrillic, Greek, extended Latin).
  Use only if you actually need those scripts.

Readex Pro is served as **one variable file** covering 200–700. That's 50 KB for
five weights instead of five separate downloads — worth having on a 3G connection
in Cairo, which is the performance budget the brand book sets (§08, §09).

---

## Checks worth running before you ship

1. Open `specimen.html`. If the Arabic renders as disconnected letters or boxes,
   the font didn't load — check your paths.
2. Confirm your build tool isn't re-subsetting the files. Some bundlers strip
   the Arabic shaping tables and the letters come apart silently.
3. Set `font-display: swap` (already in the CSS) and give the fallback stack a real
   Arabic face — on Windows that's Segoe UI, on Android Noto Sans Arabic. Without it
   the layout jumps when the webfont lands.
4. Never apply `letter-spacing` to Arabic. It breaks the joins between letters and
   the word literally falls apart. The CSS already zeroes it for `[lang="ar"]` and
   `[dir="rtl"]`, but watch for it in component-level styles.

---

## Attribution

**Readex Pro** — Thomas Jockin, Nadine Chahine, Santiago Orozco et al.
**IBM Plex Sans Arabic** and **IBM Plex Mono** — Mike Abbink, Bold Monday,
Khajag Apelian, Wael Morcos.

Sourced from the Google Fonts repository. Full licence text in `licenses/`.
