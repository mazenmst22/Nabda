# Nabda — Codex build pack

Drop `AGENTS.md` and `docs/` into the root of the Nabda frontend repo and **commit them before
you run any task**. Codex reads `AGENTS.md` on every session, which is why the task prompts in
`codex-tasks.md` are short — the constraints live in the repo, permanently, not in each prompt.

```
AGENTS.md                     ← repo root. Read by Codex on every task.
docs/00-product-brief.md      ← why the constraints exist, the voice, the Vezeeta comparison
docs/01-api-contract.md       ← every endpoint, header, error code and type
docs/02-design-tokens.md      ← palette, verified contrast, bilingual type scale, Pulse states
docs/03-screen-inventory.md   ← every screen, breakpoints, card anatomy
codex-tasks.md                ← the 16 prompts. One task per session, one task per PR.
```

Run them in order. Do not start T05 until T04 has merged — later tasks assume earlier primitives
exist on `main`. Review T00–T05 carefully; they are the foundation.

Live version with copy buttons and a progress checklist:
https://claude.ai/code/artifact/2659ee66-939a-4ed9-91a9-827e9bbd89c1
