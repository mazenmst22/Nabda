# AGENTS.md — Nabda web client

You are working in the Nabda frontend repository. Read this file completely before every task.
Everything here is a constraint, not a suggestion. When a task prompt and this file disagree,
this file wins and you should say so in your PR description.

---

## 1. What Nabda is

Nabda (نبضة) is a **clinic management system** for small and medium clinics in Egypt, plus a
patient-facing booking layer on top of it. Its organising principle is the **patient aggregate**:
appointments, encounters, recordings, transcripts, prescriptions, billing records and audit
history all resolve to one patient identity inside one clinic's scope.

**Pulse** is the embedded AI assistant. It books, reschedules and cancels appointments, answers
approved FAQs, and assists clinicians with prescription extraction from consultation audio.
Pulse is a feature of the product, not a separate chatbot product.

The nearest reference point is Vezeeta (vezeeta.com), and the difference matters:
Vezeeta is a marketplace that *lists* doctors. Nabda *runs the clinic's schedule*, so its
availability is the source of truth rather than an estimate. Match Vezeeta's Egyptian
conventions — fee visible before booking, book free and pay at the clinic — and beat it on
truthfulness of data.

### Four workspaces (all RBAC-scoped to one clinic)

| Workspace | Route group | Who |
|---|---|---|
| Public + Patient | `(public)`, `(patient)` | Anyone; signed-in patients |
| Receptionist | `(reception)` | Front desk. API/code name is **Receptionist**; "Register" is a UI label only |
| Doctor | `(doctor)` | Doctor, who is also the clinic admin |
| Developer | `(developer)` | Super admin: tenant config, providers, flags, prompts, audit, health |

The Developer role configures the system. It must **not** grant unrestricted clinical-record access.

---

## 2. Stack — fixed, do not substitute

- **Next.js 15 App Router**, React 19, **TypeScript strict** (`noUncheckedIndexedAccess` on)
- **Tailwind CSS v4** consuming CSS custom properties from `src/styles/tokens.css`
- **TanStack Query v5** for all server state — never `useEffect` + `fetch`
- **Zustand** for transient UI state only (open panels, draft text, capture state)
- **React Hook Form + Zod** for every form; Zod schemas are shared with the API layer
- **next-intl** for ar/en, with `/[locale]` routing
- **MSW** for the mocked API in dev, test and CI
- **Vitest** + Testing Library for unit, **Playwright** for E2E, **@axe-core/playwright** for a11y
- **@microsoft/signalr** for job progress (mocked until the API exists)

No component library. Build the primitives in `src/components/ui` (task T03). No Chakra, no MUI,
no shadcn scaffolding — the tokens and RTL requirements make generic kits a liability here.

### Backend

The real backend is **ASP.NET Core + EF Core**, and it does not exist yet. You are building
**frontend only**. Every network call goes through `src/lib/api/client.ts` and is intercepted by
MSW handlers in `src/mocks`. The contract in `docs/01-api-contract.md` is authoritative — code
against it exactly, so that swapping MSW for a real base URL is a one-line change.

---

## 3. Non-negotiables

### 3.1 Arabic-first, RTL-first

- **`ar` is the default locale.** English is the toggle, not the base case.
- Build RTL first. Use **CSS logical properties everywhere** — `margin-inline-start`, not
  `margin-left`; `inset-inline-end`, not `right`; `text-align: start`, not `left`.
  A PR containing `ml-`, `mr-`, `pl-`, `pr-`, `left-`, `right-` Tailwind classes will be rejected.
  Use `ms-`, `me-`, `ps-`, `pe-`, `start-`, `end-`.
- **Never apply `letter-spacing` to Arabic.** It breaks the joins and the word visually falls apart.
- **Never uppercase Arabic.** It has no case. The uppercase mono label style is Latin-only;
  Arabic labels use the body face at weight 500, same size, no tracking.
- Arabic type runs **+8% size and +0.15 line-height** against its Latin step. The tokens already
  encode this — use the `.type-*` classes, do not hand-tune.
- **Times, prices, phone numbers, IDs and reference codes are always LTR**, even inside Arabic
  text. Wrap them in `<Ltr>` (`direction: ltr; unicode-bidi: isolate`). Bidi will otherwise
  reorder `09:30` into `30:09`.
- Numerals: **Western (0–9) by default**; Eastern Arabic (٠–٩) is a user preference, honoured by
  the `useNumerals()` formatter. Never hardcode either.
- Layout mirrors in RTL. The **logo, clocks and media playback controls do not mirror.**

### 3.2 Colour has meaning

Full system in `docs/02-design-tokens.md`. Three rules you must not break:

1. **Gold `--pulse-*` is Pulse and only Pulse.** The AI avatar, AI-authored content, AI suggestions.
   Never a CTA, never a promo, never a highlight. Users learn "if it glows, it's thinking" in one
   session; using gold elsewhere destroys the only piece of learned meaning in the system.
2. **When a human takes over from Pulse, the gold must go** — the avatar cross-fades gold → teal
   and all motion stops. A user must be able to tell software from staff at a glance, without reading.
3. **Never encode status in colour alone.** Every appointment state, confidence level and job state
   carries an icon and a text label as well as a colour. Roughly 1 in 12 men in this region has a
   colour vision deficiency, and this is a clinical product.

Use semantic tokens (`--action-primary-bg`), never raw hex, never Tailwind palette colours
(`bg-blue-500` is a bug).

### 3.3 Safety rules that are UI requirements

- **A booking is not confirmed until the scheduling transaction commits.** Never render a success
  state optimistically. Show "Holding your slot…" during the hold, "Confirmed" only on the API's
  committed response.
- **An extracted prescription is not clinical truth until a clinician approves it.** Extraction
  output is always visually marked as unapproved, with confidence surfaced per field.
- **Pulse never diagnoses**, recommends medication, estimates severity, or claims to be human.
  If a user asks whether they are talking to a person, the answer is always a plain no.
- **Emergency language stops automation.** Bypass the chat and render the emergency interstitial
  with the deployment-configured numbers.
- **Consent gates recording.** The AudioCapture component cannot start without a valid, current
  consent record; there is no bypass, not even in dev.

### 3.4 Accessibility

WCAG 2.1 AA is a release gate, not a nice-to-have.

- Minimum touch target **44 × 44 px**. Body copy minimum **16 px**.
- Every interactive element is keyboard operable with a **visible focus ring** (`--border-focus`).
- 200% zoom without horizontal scroll. Reflow at 320px.
- Live regions for async progress; announcements throttled to avoid screen-reader spam.
- `prefers-reduced-motion` honoured everywhere. Pulse stops breathing; the gold stays.
- Every route passes `axe` with zero violations. This is checked in CI.

### 3.5 Performance

The user is on a mid-range Android on a patchy Cairo connection. This is a brand promise, not a
technical preference.

- **LCP < 1.8s** on Moto G Power / Slow 4G, verified by Lighthouse CI.
- **< 120 KB** of critical-path JS per route (gzipped).
- Fonts are **self-hosted, subset to Latin + Arabic**, `font-display: swap`, with a real Arabic
  fallback in the stack (Segoe UI on Windows, Noto Sans Arabic on Android) so the layout does not
  jump. They live in `public/fonts`. Do not add a Google Fonts `<link>`.
- Server components for read-heavy shells. Client components only where interaction or a media API
  requires it.
- No hero video. No carousel.

---

## 4. Repository layout

```
src/
  app/
    [locale]/
      (public)/          # directory, search, doctor + clinic pages, marketing
      (patient)/         # signed-in patient area
      (reception)/       # receptionist workspace
      (doctor)/          # doctor workspace
      (developer)/       # super-admin workspace
      layout.tsx
  components/
    ui/                  # primitives — Button, Field, Dialog, DataGrid, StatusPill…
    pulse/               # avatar, chat panel, tool-confirmation cards, handoff
    booking/             # slot picker, hold timer, price confirm
    clinical/            # AudioCapture, TranscriptEditor, ExtractionReview
    layout/              # app shells per workspace
  lib/
    api/                 # client.ts, endpoints, error taxonomy
    schemas/             # Zod — one file per aggregate, exported types
    hooks/               # TanStack Query hooks, one per resource
    i18n/                # next-intl config, formatters, numerals
    rbac/                # role guards, permission map
  mocks/                 # MSW handlers + fixtures
  styles/                # tokens.css, globals.css
messages/                # ar.json, en.json
e2e/                     # Playwright specs
docs/                    # the spec files listed below
```

Organise by **domain**, not by file type. A booking feature's component, hook, schema and mock
handler should be findable together.

---

## 5. Definition of done

A task is not complete until all of these pass:

```bash
pnpm lint          # eslint + the RTL logical-property rule
pnpm typecheck     # tsc --noEmit, strict
pnpm test          # vitest
pnpm test:e2e      # playwright, includes axe on every touched route
pnpm build         # next build, must not exceed the bundle budget
```

Plus, by inspection:

- [ ] Renders correctly in **ar (RTL)** and **en (LTR)**
- [ ] Renders correctly in **light and dark**
- [ ] Works at **320px, 768px, 1280px, 1920px**
- [ ] Keyboard-only path through the whole feature
- [ ] Loading, empty, error and permission-denied states all exist and are designed
- [ ] Every string is in `messages/ar.json` and `messages/en.json` — **no hardcoded copy**
- [ ] Arabic copy is Egyptian colloquial for patient-facing surfaces, Modern Standard for
      clinical and legal surfaces

Empty states are a design requirement, not a fallback: every one offers a route forward, and
where sensible that route is Pulse. "No cardiologist in Maadi before Thursday — ask Pulse to
widen the search?" is the pattern.

---

## 6. Conventions

- Commits: Conventional Commits (`feat(booking): …`). One task = one PR.
- Components: named exports, no default exports except Next.js pages/layouts.
- `async` server components by default; add `"use client"` only when you need state, an event
  handler, or a browser API — and put it as low in the tree as possible.
- All money is `{ amount: number, currency: "EGP" }`. Never a bare number. Format via
  `formatMoney()`, which handles locale and always renders LTR.
- All timestamps are ISO 8601 UTC on the wire; render in `Africa/Cairo` via `formatDateTime()`.
- Every mutating request sends `Idempotency-Key` and `X-Correlation-Id`. Every update sends the
  entity `version` for optimistic concurrency and handles `409 Conflict` with a real recovery UI.
- Never log PHI. Not to console, not to an error reporter, not in a Query devtools label.

## 7. Do not

- Do not install a component library, an icon mega-pack, or a CSS-in-JS runtime.
- Do not add a state manager beyond TanStack Query + Zustand.
- Do not put business rules in components — they belong in hooks or `lib/`.
- Do not use `any`, `@ts-ignore`, or non-null assertions to get past a type error.
- Do not write placeholder copy. If you need a string, write the real Arabic and English.
- Do not use lorem ipsum, stock-photo doctors, or emoji anywhere in the product.
- Do not create a README section claiming a feature works before its tests pass.
