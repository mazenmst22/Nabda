# 02 — Design tokens

Source of truth: the Nabda brand system. Where the developer specification and the brand system
disagreed, **the brand system won** — so the interface face is IBM Plex Sans Arabic (not
Alexandria), teal is primary, and lapis is demoted to data visualisation and B2B surfaces only.
Update the developer spec to match rather than reintroducing the divergence.

Write these into `src/styles/tokens.css` and expose them to Tailwind v4 via `@theme`.
Components consume **semantic** tokens only.

## Palette constants

| Name | Hex | Role |
|---|---|---|
| Nabda Teal | `#0E7C74` | primary actions, links, active state |
| Deep Pulse | `#063A38` | dark surfaces, headings on light |
| Ink | `#04191A` | body text, dark ground. Teal-biased, never neutral black |
| Faience | `#3FB6A8` | dark-mode primary, illustration |
| Mint | `#8FD9CD` | tints, dark-mode secondary, Pulse-surface actions |
| Mist | `#E3EEEC` | card fills, dividers, table headers |
| Paper | `#F4F8F7` | page ground |
| Pulse Gold | `#E5A93C` | **Pulse only** |
| Gold Glow | `#F6D08A` | Pulse highlights and text on ink |
| Gold Deep | `#8A5E10` | the only gold permitted for text on light (5.32:1) |
| Lapis | `#12305C` | data viz, B2B/clinic-facing marketing. **Never a CTA** |
| Carnelian | `#BE4224` | destructive, cancellation, error |
| Slate | `#5B7472` | secondary text, metadata, timestamps |

Verified contrast (WCAG 2.1): Ink on Paper 16.92 · Teal on Paper 4.72 · White on Teal 5.06 ·
Slate on Paper 4.69 · Carnelian on Paper 4.91 · Gold on Ink 8.69 · Faience on Ink 7.31.
**Gold on Paper is 1.95 and fails** — that is deliberate, it forces Pulse onto dark surfaces.
Use Gold Deep `#8A5E10` where gold must carry text on light.

## Semantic tokens

```
--surface-bg / -raised / -sunken / -inverse
--text-primary / -secondary / -tertiary / -inverse / -on-accent
--border-subtle / -default / -strong / -focus
--action-primary-bg / -hover / -active / -fg
--action-secondary-bg / -border / -fg
--action-ghost-fg
--action-danger-bg / -fg
--pulse-core / -glow / -surface / -fg / -fg-on-light
--data-1..6            (lapis-led sequence for charts)
--status-*             (see below)
```

Define the complete light set on bare `:root`. Redefine **only** the tokens under
`@media (prefers-color-scheme: dark) { :root:not([data-theme="light"]) { … } }` and again under
`:root[data-theme="dark"]` so an explicit choice wins in both directions. Never declare a colour
whose only definition lives inside a media or `[data-theme]` block.

## Status colours — always paired with an icon and a label

| Status | Token | Icon | Label ar / en |
|---|---|---|---|
| Available | teal | ● filled dot | متاح / Available |
| Held | gold-deep on mist | ◷ timer | محجوز مؤقتاً / Holding |
| Booked | teal | ✓ check | مؤكد / Confirmed |
| Checked in | faience | → arrow | تم الوصول / Checked in |
| In progress | lapis | ◐ half | جارٍ الكشف / In progress |
| Completed | slate | ✓✓ | انتهى / Completed |
| Cancelled | carnelian | ✕ | ملغي / Cancelled |
| No-show | slate outline | ⊘ | لم يحضر / No-show |

## Spacing, radii, elevation

Spacing base 4px, rhythm 8: `4 · 8 · 12 · 16 · 24 · 40 · 72`.

| Token | Value | Applied to |
|---|---|---|
| `--r-sm` | 8px | chips, slots, inputs |
| `--r-md` | 10px | buttons |
| `--r-lg` | 13px | cards, sheets |
| `--r-full` | 999px | avatars, badges, Pulse |
| `--e-1` | `0 1px 2px rgb(4 25 26 / .05)` | resting cards |
| `--e-2` | `0 14px 30px -22px rgb(4 25 26 / .5)` | hover, sheets |
| `--e-pulse` | `0 0 26px 6px rgb(229 169 60 / .55)` | **Pulse only — the only glow in the system** |

## Typography

Self-hosted, in `public/fonts`, subset to Latin + Arabic.

- **Readex Pro** — display and wordmark. One variable file, weights 200–700. Use 200–600; never 700.
- **IBM Plex Sans Arabic** — interface and body, 300–600.
- **IBM Plex Mono** — data, times, prices, reference codes, uppercase labels. **Latin only.**

```
--f-display: "Readex Pro", "Segoe UI", system-ui, sans-serif;
--f-body:    "IBM Plex Sans Arabic", "Readex Pro", "Segoe UI", "Noto Sans Arabic", system-ui, sans-serif;
--f-mono:    "IBM Plex Mono", ui-monospace, "SF Mono", monospace;
```

Scale — ship as `.type-display`, `.type-h1` … `.type-data`, with the Arabic adjustment applied
automatically under `[lang="ar"]` / `[dir="rtl"]`:

| Token | Latin | Arabic | Weight / face |
|---|---|---|---|
| display | 44 / 1.05 / -.035em | 47 / 1.20 / 0 | Readex 600 |
| h1 | 34 / 1.10 / -.03em | 37 / 1.25 / 0 | Readex 600 |
| h2 | 26 / 1.15 / -.025em | 28 / 1.30 / 0 | Readex 500 |
| h3 | 20 / 1.30 / -.02em | 22 / 1.45 / 0 | Readex 500 |
| body | 16 / 1.62 | 17 / 1.77 | Plex Arabic 400 |
| small | 14 / 1.55 | 15 / 1.70 | Plex Arabic 400 |
| label | 11 / 1.4 / +.14em UPPER | 13 / 1.5 / 0 normal case, **Plex Arabic 500** | Plex Mono 500 |
| data | 15 / 1.4 tabular-nums | same | Plex Mono 400 |

## Motion — two registers

- **Product (everything except Pulse):** 160–220ms, `cubic-bezier(.2,.7,.3,1)`, opacity and
  4–8px translate only. No bounce, no spring, no scale-in. A booking flow should feel like a
  door closing properly.
- **Pulse only:** continuous, breathing, 1.9–2.4s cycles. Pulse is the only element permitted to
  animate while idle. Under `prefers-reduced-motion` the breathing stops and the gold stays.

## Pulse avatar states — build to this table

| State | Form | Motion | Duration |
|---|---|---|---|
| idle | core dot | scale 1 → 1.13, glow 18 → 30px | 2.4s loop |
| listening | core + 3 rings | rings scale .34 → 1, fade out, stagger .63s | 1.9s loop |
| thinking | core + one 30° arc | arc rotates 360° linear | 1.5s loop |
| speaking | five vertical bars | scaleY .42 → 1, stagger .11s | 0.9s loop |
| acting | core + gold sweep line | line draws start → end, dissolves | 2.6s |
| done | core, one hard beat | scale to 1.3, settle to idle | 400ms |
| **handoff** | core fades **gold → teal** | cross-fade, all motion stops | 300ms |

The handoff state is a safety requirement, not a flourish. Ship it in the same PR as the avatar.
