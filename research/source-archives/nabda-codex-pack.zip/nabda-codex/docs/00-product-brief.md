# 00 — Product brief

Read `AGENTS.md` first. This file is the *why* behind the constraints.

## The category problem

Finding and booking care in Egypt still runs on WhatsApp screenshots, a receptionist who may or
may not pick up, and a neighbour's recommendation. Patients are not short of options — they are
short of **certainty**. The category's default look (stock photo of a smiling doctor, corporate
blue, English-first) reads as *foreign, expensive, probably not for me*.

So the product's job is to look **certain** first and intelligent second. One tap, one beat, and
the machinery moves: the doctor is found, the slot is held, the reminder is sent, Pulse is awake
at 2am.

## Against the reference

Vezeeta is the market reference. Match its Egyptian conventions and beat it on truthfulness:

| | Vezeeta | Nabda |
|---|---|---|
| Relationship to the clinic | Lists doctors | **Runs the clinic's schedule** |
| Availability | Aggregated, can be stale | Source of truth — the same record the front desk uses |
| Waiting time | Estimated | Real queue position is available because Nabda owns the queue. Surface it in the staff workspaces in v1; hold it back from the patient card until the queue data is trustworthy in production |
| Fee | Shown before booking ✓ | Same — non-negotiable |
| Payment | Book free, pay at clinic ✓ | Same. Online payment optional per clinic |
| Placement | Sponsored results | None. Ranking is availability, rating and distance, and we say so |
| AI | — | Pulse books and manages conversationally, in Egyptian colloquial Arabic |

## Two audiences, two doors

Nabda sells software to clinics and delivers demand to them. The directory (`/search`) is
Nabda-branded discovery across member clinics. The white-label clinic page (`/clinic/[slug]`) is
what a clinic links from its own Facebook page and Google listing. Both book into the same
scheduling module. Do not build two booking flows.

## The three sentences that define success

1. A booking is not confirmed until the scheduling service commits it.
2. An extracted prescription is not clinical truth until a clinician approves it.
3. Every sensitive action is attributable, testable, and reversible where policy permits.

If a UI decision would violate one of these to look faster or smoother, it is the wrong decision.

## Voice

Plain, never simplified. Certain, never boastful. Warm, never familiar. Calm under bad news.

- Not "Oops! Something went wrong 😥" → "We couldn't hold that slot — someone booked it 40
  seconds ago. Here are three more with Dr. Farouk this week."
- Not "Book now and save!" → "Dr. Farouk has 09:30 open today. EGP 450."
- Not "Your AI-powered health companion" → "Ask Pulse. It knows every clinic's hours and can book
  for you."

Patient-facing Arabic is **Egyptian colloquial**. MSA on a consumer screen reads as government
paperwork. Clinical and legal surfaces use MSA. Address patients as حضرتك, never the casual second
person. No emoji anywhere in the product.
