# 01 — API contract

The ASP.NET Core API does not exist yet. This document **is** the contract. Build the typed client
and the MSW handlers against it exactly, so swapping to the real API is a base-URL change.

Base: `/{version}` where version is `v1`. All responses JSON. All timestamps ISO 8601 UTC.

## Conventions on every request

| Header | When | Notes |
|---|---|---|
| `Authorization: Bearer <token>` | always | short-lived OIDC access token |
| `X-Clinic-Id` | always | tenant scope; every query path is clinic-scoped server-side |
| `X-Correlation-Id` | always | uuid v4, generated per user action, reused across retries |
| `Idempotency-Key` | POST/PATCH/DELETE | uuid v4, stable across retries of the same intent |
| `If-Match: <version>` | PATCH/PUT | optimistic concurrency; `409` on mismatch |
| `Accept-Language` | always | `ar` or `en` |

## Error envelope

```jsonc
{
  "type": "https://nabda.health/errors/slot-taken",
  "title": "Slot no longer available",
  "status": 409,
  "code": "SLOT_TAKEN",          // stable machine code — switch on this, never on title
  "detail": "…",                  // safe to show, already localised by Accept-Language
  "correlationId": "…",
  "errors": { "fieldName": ["…"] } // present on 422 only
}
```

Codes the UI must handle explicitly: `SLOT_TAKEN`, `HOLD_EXPIRED`, `VERSION_CONFLICT`,
`CONSENT_REQUIRED`, `CONSENT_REVOKED`, `NOT_AUTHORIZED`, `CLINIC_SCOPE_VIOLATION`,
`EXTRACTION_INVALID_JSON`, `PROVIDER_UNAVAILABLE`, `RATE_LIMITED`.
`NOT_AUTHORIZED` must never disclose whether the resource exists.

## Resources

### Directory & search (public, unauthenticated)
```
GET  /v1/public/clinics                       ?q&city&district&page
GET  /v1/public/clinics/{slug}
GET  /v1/public/specialties
GET  /v1/public/doctors                       ?specialty&subSpecialty&city&district&clinicId
                                              &gender&title&feeMin&feeMax&availability=any|today|tomorrow
                                              &sort=best|rating|feeAsc|feeDesc|soonest&page
GET  /v1/public/doctors/{slug}
GET  /v1/public/doctors/{id}/availability     ?from&to        → DaySlots[]
```

### Scheduling
```
POST   /v1/appointments/holds                 { doctorId, slotStart, patientId? } → Hold
DELETE /v1/appointments/holds/{holdId}
POST   /v1/appointments                       { holdId, patientId, source } → Appointment
GET    /v1/appointments                       ?patientId|doctorId&from&to&status
GET    /v1/appointments/{id}
PATCH  /v1/appointments/{id}                  { status | slotStart }  (If-Match required)
GET    /v1/queue                              ?doctorId&date → QueueEntry[]
PATCH  /v1/queue/{entryId}                    { state }
```

### Patients
```
GET   /v1/patients            ?q&page
POST  /v1/patients
GET   /v1/patients/{id}
PATCH /v1/patients/{id}       (If-Match)
GET   /v1/patients/{id}/timeline      → aggregate feed: appointments, encounters, prescriptions
```

### Encounters, audio, transcripts, extraction
```
POST  /v1/consents                            { patientId, encounterId?, purpose, textVersion } → ConsentRecord
DELETE /v1/consents/{id}                      revoke
POST  /v1/encounters                          { patientId, appointmentId?, doctorId } → Encounter
POST  /v1/encounters/{id}/audio/upload-url    { contentType, bytes } → { uploadUrl, audioKey }
POST  /v1/encounters/{id}/audio/complete      { audioKey, sha256, durationMs } → Job
GET   /v1/jobs/{jobId}                        → Job
GET   /v1/encounters/{id}/transcript          → Transcript
PATCH /v1/encounters/{id}/transcript          { segments } (If-Match) → new version
POST  /v1/encounters/{id}/extraction          → Job
GET   /v1/encounters/{id}/prescriptions       → Prescription[]
POST  /v1/encounters/{id}/prescriptions       { payload } → Prescription (status: draft)
POST  /v1/prescriptions/{id}/approve          { signature } → Prescription (status: approved)
```

### Pulse
```
POST /v1/pulse/conversations                  → PulseConversation
POST /v1/pulse/conversations/{id}/messages    { text }  → streamed via SSE or SignalR
POST /v1/pulse/conversations/{id}/confirm     { toolCallId, confirmed: boolean }
POST /v1/pulse/conversations/{id}/handoff     → { assignedTo, status: "human" }
```
The model may **propose** a tool call. The UI must render it as an explicit confirmation card
naming doctor, date, time and price, and nothing commits until the user confirms and the API
returns a committed appointment.

### Developer / admin
```
GET   /v1/admin/settings   PATCH /v1/admin/settings
GET   /v1/admin/providers  PATCH /v1/admin/providers/{id}
GET   /v1/admin/flags      PATCH /v1/admin/flags/{key}
GET   /v1/admin/prompts    POST  /v1/admin/prompts        (new version)
GET   /v1/admin/audit      ?actor&entity&from&to&page
GET   /v1/admin/health     → { api, db, queue, storage, providers[] }
```

## Core types (write these as Zod schemas in `src/lib/schemas`)

```ts
Money        = { amount: number; currency: "EGP" }
Appointment  = { id, patientId, doctorId, clinicId, locationId,
                 start: string, end: string,
                 status: "held"|"booked"|"checked_in"|"in_progress"|"completed"|"cancelled"|"no_show",
                 price: Money, source: "patient_web"|"reception"|"pulse",
                 holdExpiresAt?: string, version: number }
Hold         = { holdId, doctorId, slotStart, expiresAt, price: Money }
DaySlots     = { date: string, slots: { start, end, available: boolean }[] }
QueueEntry   = { id, appointmentId, patientId, position: number,
                 state: "waiting"|"called"|"in_room"|"done"|"skipped", estimatedWaitMin: number }
Doctor       = { id, slug, nameAr, nameEn, title, specialties[], subSpecialties[], gender,
                 clinicId, photoUrl?, rating: { average, count }, fee: Money,
                 nextAvailable?: string, acceptsOnlinePayment: boolean, bio }
Clinic       = { id, slug, nameAr, nameEn, city, district, address, phone, hours[], logoUrl?,
                 theme?: { accent?: string } }   // theme drives white-label clinic pages only
Job          = { jobId, kind: "transcription"|"extraction",
                 state: "queued"|"running"|"succeeded"|"failed_retryable"|"failed_terminal"|"cancelled",
                 progress: number, error?, attempts: number }
Transcript   = { encounterId, version, language, status,
                 segments: { speaker: "doctor"|"patient"|"unknown", start, end, text,
                             confidence: number, edited: boolean }[] }
```

## Prescription extraction payload — exact shape, do not alter

```json
{
  "patientId": "string",
  "encounterId": "string",
  "extractedAt": "ISO8601 timestamp",
  "medications": [
    { "rawText": "string", "normalizedName": "string", "dose": 0, "unit": "string",
      "frequency": "string", "route": "string", "duration": "string", "notes": "string",
      "confidence": 0.0 }
  ],
  "modelInfo": { "provider": "string", "model": "string", "version": "string" }
}
```

Validate with Zod before rendering or storing. `rawText` is preserved for traceability and is
always shown next to the normalised value in the review UI. Any field with `confidence < 0.85`
renders with the uncertainty treatment and cannot be approved without an explicit per-field
acknowledgement.

## SignalR

Hub `/hubs/jobs`. Events: `jobProgress { jobId, progress, state }`, `jobCompleted { jobId, result }`,
`jobFailed { jobId, error, retryable }`. **Deduplicate by `jobId` + sequence** — reconnects replay.
Treat the REST `GET /v1/jobs/{id}` response as authoritative if they disagree.
