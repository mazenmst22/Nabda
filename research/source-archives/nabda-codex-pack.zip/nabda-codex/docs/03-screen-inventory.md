# 03 — Screen inventory

Breakpoints: **320 / 390 (design target) / 768 / 1024 / 1280 / 1920**. Design mobile-first at 390.
Roughly 85% of patient traffic is a mid-range Android. Staff workspaces are desktop-first but must
remain usable at 768 — receptionists work on small laptops and doctors check schedules on phones.

## A. Public directory — `(public)`, no auth

| Route | Screen | Notes |
|---|---|---|
| `/[locale]` | Home | Search hero is the whole page. Headline states an outcome, not a value proposition. Live search field above the fold at 390px. Below: specialty tiles, three real doctor cards from live availability, Pulse demo band (the only ink-grounded section), trust row with numbers not adjectives, for-clinics band in lapis, footer with the interval motif |
| `/[locale]/search` | Results | Filters: specialty, sub-specialty, district, availability (any/today/tomorrow), fee range, gender, title, accepts online payment. Sort: best match, top rated, fee ↑, fee ↓, soonest. Filters are a bottom sheet on mobile, a sidebar ≥1024 |
| `/[locale]/doctor/[slug]` | Doctor profile | Fee and next slot above the fold. Bio, sub-specialties, clinic + map, reviews, inline slot picker |
| `/[locale]/clinic/[slug]` | Clinic page (white-label) | Clinic's own branding via `clinic.theme.accent`; Nabda mark reduced to a footer "powered by". This is the page a clinic links from its Facebook and Google listing. Doctors list, hours, address, direct booking |
| `/[locale]/specialties`, `/specialty/[slug]` | Browse | Arabic-labelled tiles, outline icons |
| `/[locale]/for-clinics` | B2B | Lapis accent, Musallab mark, numbers-led. Never consumer copy |
| `/[locale]/help`, `/about`, `/terms`, `/privacy` | Static | Full clinic-registration and licence details in the footer — regulatory transparency is a trust asset in this market |

**Doctor card anatomy, in this order:** name · title · specialty tags · district · **fee in EGP** ·
rating + review count · next available slot · `Book 09:30` (names the actual slot, never "Book now").
"احجز مجاناً وادفع في العيادة / Book free, pay at the clinic" appears at the booking step.

## B. Booking flow — shared, `(public)` → `(patient)`

Slot picker → **hold with visible countdown** → identify or register patient → price confirmation
(doctor, date, time, fee, payment location) → commit → confirmation with add-to-calendar.

States that must exist and be designed: hold expiring (<60s warning), hold expired, `SLOT_TAKEN`
with three alternative slots offered, network failure with idempotent retry, and a signed-out
recovery that preserves the intended slot through auth.

## C. Patient workspace — `(patient)`

Appointments (upcoming / past) · appointment detail with reschedule and cancel · prescriptions
(**approved only**, never drafts) · encounter summaries where clinic policy permits · notification
preferences (SMS / email / WhatsApp, per event type) · profile with language and numeral preference.

## D. Receptionist workspace — `(reception)`

Day schedule grid across all doctors (columns = doctors, rows = time) · create / move / cancel
appointment · **queue board** with waiting / called / in-room / done / skipped and drag between
states · patient search and quick-create · billing-lite (mark paid, record amount, print receipt) ·
Pulse assist panel with human-takeover button.

Keyboard-first is a hard requirement: `/` focus search, `n` new appointment, `j`/`k` move through
queue, `Enter` call next. The front desk is under time pressure and will not use a mouse.

## E. Doctor workspace — `(doctor)`

My schedule (day / week) · patient chart = **the patient aggregate**, one page: demographics,
timeline, encounters, prescriptions, billing, audit links · start encounter → **consent gate** →
AudioCapture (record, pause, waveform, duration, retry, upload progress) · transcript editor with
speaker tags and per-segment confidence · extraction review table with per-field confidence and
`rawText` alongside each normalised value · approve + sign → versioned prescription · prescription
history with version diff.

## F. Developer workspace — `(developer)`

Tenant settings · provider configuration (STT and LLM: provider, model, region, timeout, confidence
threshold, retention) · feature flags · prompt template versions with diff · audit log viewer with
actor/entity/date filters · job and health dashboard (queue depth, p50/p95 latency, failure rate,
provider status).

This role configures the system and **must not** expose unrestricted clinical records. Build the
guard, and write a test that proves it.

## G. Pulse — everywhere

Docked panel on desktop (≥1024), full-screen sheet on mobile, plus a dedicated `/pulse` route.
Message list with the avatar state machine, streamed responses, **tool-confirmation cards** naming
doctor/date/time/price with explicit confirm and cancel, emergency interstitial that replaces the
composer entirely, and human handoff that removes the gold.

Pulse is also the empty-state recovery across the product. Every "no results" offers it.
