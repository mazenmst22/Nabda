# Nabda — Codex task sequence

**How to use this.** Put `AGENTS.md` and `docs/` at the repo root and commit them before you start.
Then run **one task per Codex session, one task per PR**. Paste the task body verbatim; Codex reads
`AGENTS.md` automatically and you do not need to restate the constraints. Do not run T05+ until the
task before it has merged — later tasks assume the primitives from earlier ones exist.

If Codex proposes deviating from `AGENTS.md`, make it say so in the PR description rather than
silently doing it. That is how you find out the constraint was wrong.

Tasks T00–T05 are the foundation and are worth reviewing carefully; T06–T14 are feature work and
can move faster. T15 is the gate.

---

## T00 — Scaffold and guardrails

Initialise the Nabda web client. Next.js 15 App Router, React 19, TypeScript strict with
`noUncheckedIndexedAccess`, pnpm.

Set up: Tailwind CSS v4; ESLint (flat config) + Prettier; Vitest + Testing Library; Playwright with
`@axe-core/playwright`; MSW for node and browser; `next-intl` with `/[locale]` routing where **`ar`
is the default locale and the default direction is RTL**; Husky + lint-staged.

Create the route-group skeleton from `docs/03-screen-inventory.md` — `(public)`, `(patient)`,
`(reception)`, `(doctor)`, `(developer)` — each with a placeholder `layout.tsx` and `page.tsx` that
renders its own name. Nothing styled yet.

Write a **custom ESLint rule** `nabda/no-physical-properties` that errors on the Tailwind classes
`ml-`, `mr-`, `pl-`, `pr-`, `left-`, `right-`, `text-left`, `text-right`, `border-l`, `border-r`,
and on the CSS properties `margin-left/right`, `padding-left/right`, `left`, `right` in any
`.css` file. Message: use the logical equivalent. Add it to the config and prove it fires with a
test fixture.

Add the scripts `lint`, `typecheck`, `test`, `test:e2e`, `build`, `dev`, and a GitHub Actions
workflow that runs all of them on PR.

**Done when:** `pnpm lint && pnpm typecheck && pnpm test && pnpm build` all pass, `/ar` and `/en`
both render with the correct `dir` on `<html>`, and the custom lint rule demonstrably fails on a
`ml-4` fixture.

---

## T01 — Design tokens, fonts, themes

Implement `docs/02-design-tokens.md` in full.

Write `src/styles/tokens.css` with the complete light palette on bare `:root`, the dark overrides
under both `@media (prefers-color-scheme: dark) { :root:not([data-theme="light"]) }` **and**
`:root[data-theme="dark"]`, and nothing — no colour anywhere in the codebase — declared only inside
a media or `[data-theme]` block. Expose the semantic tokens to Tailwind v4 through `@theme`.

Self-host the fonts. Put the subset `.woff2` files in `public/fonts` and write the `@font-face`
rules with `font-display: swap` and the Arabic-capable fallback stack. Readex Pro ships as one
variable file covering 200–700. **Do not add a Google Fonts link.**

Implement the type scale as utility classes `.type-display` through `.type-data`, with the Arabic
adjustment (+8% size, +0.15 line-height, tracking zeroed, uppercase disabled) applied automatically
under `[lang="ar"]` and `[dir="rtl"]`. The `.type-label` uppercase mono style must switch to IBM
Plex Sans Arabic 500 at normal case in Arabic.

Add a theme provider with three states — system, light, dark — persisted to `localStorage`,
guarded in try/catch, with no flash of the wrong theme on first paint.

Build a `/dev/tokens` page that renders every token: colour swatches with their hex and computed
contrast ratio against their intended background, the full type scale in both scripts, spacing,
radii, elevation, and the two motion registers.

**Done when:** `/dev/tokens` is correct in ar and en, light and dark; no hardcoded hex exists
outside `tokens.css`; axe passes.

---

## T02 — Bilingual primitives and formatters

Build the i18n layer that everything else depends on.

Configure `next-intl` with `messages/ar.json` and `messages/en.json`, namespaced by domain
(`common`, `booking`, `pulse`, `clinical`, `admin`). Add a middleware locale redirect defaulting
to `ar`, and a language switcher that preserves the current path and query.

Ship these components and hooks:

- `<Ltr>` — wraps content in `direction: ltr; unicode-bidi: isolate`. Every time, price, phone
  number, ID and reference code in the product goes through it.
- `formatMoney({ amount, currency })` — EGP, locale-aware, always rendered LTR.
- `formatDateTime(iso, opts)` — renders in `Africa/Cairo` from a UTC ISO string; never uses the
  browser's timezone.
- `formatRelative(iso)` — "in 20 minutes" / "بعد ٢٠ دقيقة".
- `useNumerals()` — returns a formatter honouring the user's Western/Eastern Arabic numeral
  preference, default Western. Never hardcode either numeral system anywhere.
- `<Plural>` — Arabic has six plural forms. Use ICU message format; do not concatenate strings.

Write a Vitest suite covering: bidi isolation of a time inside an Arabic sentence, EGP formatting
in both locales, Cairo timezone conversion across a DST boundary, Eastern numeral substitution,
and Arabic zero/one/two/few/many/other plural selection.

**Done when:** the test suite passes and a demo route shows an Arabic paragraph containing a time,
a price and a phone number all rendering in the correct order.

---

## T03 — UI primitives

Build the component library in `src/components/ui`. No third-party kit.

`Button` (primary / secondary / ghost / danger / pulse, with loading and disabled), `IconButton`,
`Field` (label + control + hint + error, wired to React Hook Form), `Input`, `Textarea`, `Select`,
`Combobox` (async, keyboard-navigable), `DatePicker` (Gregorian, Arabic month names, week starts
Saturday), `TimeSlotChip` (available / selected / unavailable), `Dialog`, `Sheet` (bottom on
mobile, side on desktop), `Toast`, `StatusPill`, `Badge`, `Card`, `DataGrid` (sortable, sticky
header, horizontal scroll contained), `Tabs`, `Avatar`, `Pagination`, `EmptyState`, `Skeleton`,
`Tooltip`, `ConfirmDialog`.

Every one of them: minimum 44×44px hit area, visible focus ring using `--border-focus`, correct in
RTL and LTR, correct in light and dark, `prefers-reduced-motion` respected, no colour-only state.

`StatusPill` implements the status table in `docs/02-design-tokens.md` — colour **plus** icon
**plus** label, always all three.

Build a `/dev/ui` gallery page showing every component in every state, with an ar/en toggle and a
light/dark toggle, and write a Playwright axe check that walks it.

**Done when:** the gallery has zero axe violations in all four combinations of locale and theme,
and keyboard traversal reaches every interactive element in a sensible order.

---

## T04 — API layer, schemas and mocks

Implement `docs/01-api-contract.md` exactly.

Write one Zod schema file per aggregate in `src/lib/schemas` — `patient`, `appointment`, `hold`,
`queue`, `doctor`, `clinic`, `encounter`, `consent`, `transcript`, `prescription`, `job`, `pulse`,
`admin` — exporting both the schema and the inferred type. The prescription extraction schema must
match the JSON contract byte for byte.

Write `src/lib/api/client.ts`: a typed fetch wrapper that attaches `Authorization`, `X-Clinic-Id`,
`X-Correlation-Id` (uuid per user action, reused across retries), `Idempotency-Key` on every
mutation, `If-Match` on every update, and `Accept-Language`. It parses the error envelope into a
discriminated union keyed on `code`, and validates every response body with its Zod schema —
failing loudly in dev, reporting and degrading in production.

Write TanStack Query hooks per resource with sensible `staleTime` (availability 30s, directory 5m,
patient records 0), optimistic updates only where safe, and **never** for booking commits.

Write MSW handlers plus fixtures with realistic Egyptian data: doctor names in Arabic and English,
Cairo and Giza districts (المعادي، مصر الجديدة، الدقي، المهندسين، مدينة نصر، الشيخ زايد), the
specialty list from `docs/03`, EGP fees in the 250–900 range, clinic hours with a Friday gap,
and availability patterns that produce real conflicts. Include handlers that deliberately return
`SLOT_TAKEN`, `HOLD_EXPIRED`, `VERSION_CONFLICT` and `PROVIDER_UNAVAILABLE` so the UI states are
exercisable, plus a latency knob and an offline mode.

**Done when:** every endpoint in the contract has a handler and a passing contract test asserting
the response satisfies its schema.

---

## T05 — Auth, RBAC and the four app shells

Build the session and permission layer, then the shells.

Mock an OIDC-shaped session (`user`, `roles[]`, `clinicId`, `exp`) behind
`src/lib/auth/session.ts`, so swapping to a real provider touches one file. Implement a permission
map in `src/lib/rbac` — resource × action × role — and a `<Can>` component plus a `requireRole()`
server guard. Unauthorised access renders a 403 that **does not disclose whether the resource
exists**.

Build four shells in `src/components/layout`: public (marketing header, footer, language and theme
toggles), patient (bottom tab bar on mobile, side nav on desktop), staff (dense side nav, clinic
switcher, global search, keyboard-shortcut help), developer (same staff chrome, distinct accent so
nobody confuses environments).

Add the session-expiry warning with safe renewal, and step-up re-authentication for privileged
configuration.

Write tests proving: a receptionist cannot reach `(doctor)` routes, a developer cannot read a
clinical record, and a patient cannot read another patient's appointment.

**Done when:** those three tests pass and each shell is correct at 320 / 768 / 1280 in both directions.

---

## T06 — Public directory and white-label clinic pages

Build everything under `(public)` from `docs/03-screen-inventory.md` section A.

Home: the search field is the hero and must be above the fold at 390px. Headline states an outcome
("طبيب متاح فعلاً اليوم"), not a value proposition. Below it: specialty tiles, three doctor cards
populated from live availability, the Pulse demo band as the only ink-grounded section on the page,
a trust row of numbers, a lapis for-clinics band, and the footer.

Search results: the filter set from `docs/03` as a bottom sheet on mobile and a sidebar at ≥1024,
with filter state in the URL so results are shareable and back works. Doctor card in the specified
order, leading with fee and the real next slot, and a primary button that names the slot
("احجز ٩:٣٠ / Book 09:30"), never "Book now".

Doctor profile: fee and next slot above the fold, inline slot picker.

Clinic page `/clinic/[slug]`: renders in the clinic's own accent from `clinic.theme.accent`, with
Nabda reduced to a "powered by" mark in the footer. Same booking flow, different chrome — do not
fork the booking code.

Add SEO metadata, `hreflang` for ar and en, JSON-LD `Physician` and `MedicalClinic`, and OG cards.

**Done when:** Lighthouse LCP < 1.8s on Slow 4G for home and search, every route passes axe, and
filter state survives a page reload and a back-navigation.

---

## T07 — Booking flow

Build the flow in `docs/03` section B, shared by the directory and the clinic pages.

Slot picker → hold with a **visible countdown** → identify or register the patient → price
confirmation naming doctor, date, time, fee and where payment happens → commit → confirmation.

Requirements. The hold `POST` returns `expiresAt`; render a live countdown and warn at 60 seconds.
Never render success optimistically — the confirmation state comes only from the committed
`Appointment` response. Send `Idempotency-Key` on the commit and reuse it across retries so a
double-tap or a flaky connection cannot double-book. Handle `SLOT_TAKEN` by offering three
alternative slots with the same doctor, and `HOLD_EXPIRED` by returning to the picker with the
selection preserved. Preserve the intended slot through a sign-in redirect.

Copy: "احجز مجاناً وادفع في العيادة / Book free, pay at the clinic" at the confirmation step.
Show the fee at every step, never only at the end.

Add an add-to-calendar (.ics) download and the "what happens next" summary — reminder timing,
clinic address, what to bring.

**Done when:** a Playwright spec covers the happy path plus slot-taken, hold-expired, network-retry
and signed-out-recovery, and the double-submit test proves only one appointment is created.

---

## T08 — Patient workspace

Build `(patient)` from `docs/03` section C: appointments split upcoming and past, appointment detail
with reschedule and cancel, prescriptions, encounter summaries, notification preferences, profile.

Reschedule reuses the T07 picker and holds the new slot **before** releasing the old one. Cancel
requires a `ConfirmDialog` naming the doctor and time, and states the clinic's cancellation policy.

Prescriptions list shows **approved versions only** — a draft or unapproved extraction must never
be reachable from a patient surface. Write a test that proves it.

Notification preferences are a matrix of channel (SMS / email / WhatsApp) × event (booking
confirmed, reminder 24h, reminder 1h, cancelled, prescription ready), with the clinic's defaults
pre-set and a clear note about which are mandatory.

Profile carries the language and the **numeral system** preference, which must immediately change
rendering across the app.

**Done when:** every list has a designed empty state that offers Pulse as the way forward, and the
approved-only prescription test passes.

---

## T09 — Pulse

Build the assistant surface from `docs/03` section G and the state table in `docs/02`.

`PulseAvatar` implements all seven states including **handoff**, which cross-fades gold → teal and
stops all motion. Ship handoff in this PR, not later — it is the safety affordance that lets a user
tell software from staff.

`PulseChat`: docked panel ≥1024, full-screen sheet below, plus a `/pulse` route. Streamed responses
rendered progressively with a live region that announces completion, not every token. Message list
virtualised, keyboard operable, with the composer disabled while a tool confirmation is pending.

`ToolConfirmationCard`: when Pulse proposes a booking, render an explicit card naming doctor, date,
time and fee, with Confirm and Cancel. **Nothing commits until the user confirms and the API
returns a committed appointment.** Reuse the T07 commit path — do not write a second booking code path.

`EmergencyInterstitial`: on an emergency signal the composer is replaced entirely by the
deployment-configured emergency guidance and numbers. There is no dismiss-and-continue.

Guard rails in the UI: if the user asks whether they are talking to a human, the answer is a plain
no. Pulse never renders a diagnosis, a medication recommendation, or a severity estimate — if the
API returns one, the UI shows a refusal template instead.

Wire Pulse into every empty state in the product as the recovery route.

**Done when:** a Playwright spec covers propose → confirm → committed, propose → cancel →
nothing created, emergency interception, and handoff removing the gold.

---

## T10 — Receptionist workspace

Build `(reception)` from `docs/03` section D.

Day schedule grid: doctors as columns, time as rows, appointments as blocks coloured and iconed by
status. Drag to move an appointment, with a confirmation naming the patient and the new time, an
optimistic-concurrency `If-Match`, and a real recovery on `VERSION_CONFLICT`.

Queue board: waiting / called / in-room / done / skipped, with position and estimated wait. This is
where Nabda's real queue data lives — the estimate comes from the clinic's own schedule, not a guess.

Patient search with quick-create, and billing-lite: mark paid, record amount, print a receipt.

**Keyboard-first is a hard requirement.** `/` focuses search, `n` creates an appointment, `j`/`k`
move through the queue, `Enter` calls the next patient, `?` opens shortcut help. The front desk is
under time pressure and will not reach for a mouse. Write a Playwright spec that completes a full
booking using only the keyboard.

Include the Pulse assist panel with a prominent human-takeover button that visibly removes the gold.

**Done when:** the keyboard-only spec passes, the grid is usable at 768px, and a concurrent-edit
test produces a recoverable conflict rather than silent data loss.

---

## T11 — Doctor workspace and audio capture

Build `(doctor)` from `docs/03` section E, through to the end of recording.

My schedule (day and week). Patient chart as **one page** representing the patient aggregate:
demographics, timeline, encounters, prescriptions, billing, audit links.

Start encounter → **consent gate**. The `AudioCapture` component cannot start without a valid,
current consent record; there is no bypass, not in dev, not behind a flag. Render the consent text
version being agreed to, and handle revocation mid-encounter by stopping capture immediately.

`AudioCapture` owns: idle, requesting-permission, consent-required, recording, paused, stopping,
uploading, upload-failed-retryable, done, device-error. Use MediaRecorder and getUserMedia, show a
live waveform and duration, support pause and resume, upload via the signed URL, and **discard the
browser-held audio as soon as the upload is confirmed**. Retries are idempotent on the same
`audioKey`. Surface a clear device-error state for a blocked or missing microphone.

Wire SignalR (mocked) for job progress, deduplicating by `jobId` and sequence, and treating the
REST job endpoint as authoritative when they disagree.

**Done when:** every one of the ten capture states is reachable in a test, consent cannot be
bypassed, and a simulated reconnect does not double-count progress.

---

## T12 — Transcript editor and extraction review

Build the clinical review surface — the highest-stakes screen in the product.

Transcript editor: speaker-tagged segments, per-segment confidence rendered as a visual weight
rather than a colour alone, inline editing that creates a **new version** rather than mutating,
version history, and a diff between versions. Support Arabic, English and code-switched segments,
with correct shaping and bidi isolation of numbers inside them.

Extraction review: a table of medications from the exact JSON contract. Each row shows the
normalised value **and** the original `rawText` beside it — traceability is not optional. Every
field carries its confidence; anything below 0.85 renders with the uncertainty treatment and
requires an explicit per-field acknowledgement before it can be approved. Editing a field marks it
edited and records who edited it.

The whole surface is visibly marked **unapproved** until a clinician approves. Approval requires a
confirmation dialog that restates the medication list, and produces a new versioned prescription
with the approving actor and timestamp. Prescription history shows every version with a diff.

Handle `EXTRACTION_INVALID_JSON` by showing the failure honestly and offering re-extraction — never
by rendering partial or guessed data.

**Done when:** a Playwright spec covers low-confidence blocking approval, edit-then-approve
producing a new version, invalid JSON handled without rendering partial data, and the unapproved
state never leaking into a patient-facing route.

---

## T13 — Developer workspace

Build `(developer)` from `docs/03` section F: tenant settings; provider configuration for the STT
and LLM adapters (provider, model, region, timeout, confidence threshold, retention) with
validation and a masked-secret display requiring step-up re-authentication to reveal; feature flags;
prompt template versions with a diff view and the ability to publish a new version; an audit log
viewer filterable by actor, entity and date range; and a health dashboard showing queue depth,
p50/p95 job latency, failure rate and per-provider status.

The permission guard from T05 must prevent this role from reading clinical records. Write the test
that proves it, and make the 403 non-disclosing.

Destructive actions confirm using the object's name and state the consequence.

**Done when:** the clinical-record guard test passes, secrets are masked until step-up, and the
audit viewer handles 10,000 rows without blocking the main thread.

---

## T14 — Notifications and reminders

Build the notification preview and template surface. Render each template (booking confirmed,
reminder 24h, reminder 1h, cancelled, rescheduled, prescription ready) in SMS, email and WhatsApp
form, in both Arabic and English, with real appointment data substituted.

SMS is constrained: show the character count and the segment count, and warn that Arabic uses UCS-2
at 70 characters per segment rather than 160 — this materially changes cost at volume.

Add the clinic-side template editor with variable insertion and a live preview, and a send-log view
with delivery status per channel.

**Done when:** every template renders correctly in both languages, the Arabic segment counter is
correct, and no template contains a hardcoded string outside the message catalogues.

---

## T15 — Quality gate

No new features. Make the release gates real.

Playwright E2E for the two golden paths end to end:
1. Patient: search → doctor → hold → book → reminder preference → reschedule → cancel.
2. Clinical: receptionist books → doctor starts encounter → consent → record → upload → transcript
   → edit → extract → review → approve → patient sees the approved prescription.

Both must run in ar-RTL and en-LTR.

Add: `axe` on every route in the app with zero violations; RTL visual-regression snapshots at 390
and 1280; Lighthouse CI with a budget that fails the build above **LCP 1.8s on Slow 4G** or
**120 KB critical-path JS per route**; a bundle-size report per route in the PR comment.

Write the README (setup, scripts, architecture, how to swap MSW for the real API) and a short
runbook covering the mock modes, the latency and offline knobs, and how to reproduce each error
code locally.

Finally, produce `docs/GAPS.md` listing everything in the developer specification that the frontend
now expects from the API but which is not yet built, so the backend team has an exact worklist.

**Done when:** CI is green with all gates enabled and `docs/GAPS.md` exists.
